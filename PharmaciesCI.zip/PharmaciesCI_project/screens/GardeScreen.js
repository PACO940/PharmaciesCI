import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, TextInput, TouchableOpacity, ActivityIndicator } from 'react-native';
import { initializeApp } from 'firebase/app';
import { getFirestore, collection, query, where, getDocs } from 'firebase/firestore';
import DateTimePicker from '@react-native-community/datetimepicker';
import { firebaseConfig } from '../config/firebaseConfig';

initializeApp(firebaseConfig);
const db = getFirestore();

export default function GardeScreen() {
  const [city, setCity] = useState('Abidjan');
  const [date, setDate] = useState(new Date());
  const [list, setList] = useState([]);
  const [loading, setLoading] = useState(false);

  const fetchGarde = async () => {
    setLoading(true);
    try {
      const dateStr = date.toISOString().slice(0,10);
      const coll = collection(db, 'gardeSchedules');
      const q = query(coll, where('city', '==', city), where('date', '==', dateStr));
      const snap = await getDocs(q);
      const items = [];
      snap.forEach(d => items.push({ id: d.id, ...d.data() }));
      setList(items);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchGarde(); }, [city, date]);

  return (
    <View style={{ flex:1, padding:12 }}>
      <Text style={{ fontWeight:'700', fontSize:18 }}>Pharmacies de garde</Text>
      <TextInput value={city} onChangeText={setCity} placeholder="Ville" style={{ borderWidth:1, padding:8, borderRadius:8, marginTop:8 }} />
      <DateTimePicker value={date} mode="date" display="default" onChange={(e, d)=> d && setDate(d)} />
      <TouchableOpacity onPress={fetchGarde} style={{ padding:10, backgroundColor:'#1e90ff', borderRadius:8, marginTop:8 }}>
        <Text style={{ color:'white' }}>Rechercher</Text>
      </TouchableOpacity>
      {loading ? <ActivityIndicator /> : (
        <FlatList data={list} keyExtractor={i=>i.id} renderItem={({item}) => (
          <View style={{ padding:12, borderBottomWidth:1, borderColor:'#eee' }}>
            <Text style={{ fontWeight:'700' }}>{item.pharmacyName || item.pharmacyId}</Text>
            <Text>{item.startAt ? new Date(item.startAt.seconds*1000).toLocaleString() : item.startAt}</Text>
          </View>
        )} />
      )}
    </View>
  );
}
