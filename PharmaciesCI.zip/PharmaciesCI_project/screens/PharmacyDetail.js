import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, TouchableOpacity, ActivityIndicator, Linking } from 'react-native';
import { getFirestore, doc, getDoc, collection, getDocs, query, orderBy } from 'firebase/firestore';
import { initializeApp } from 'firebase/app';
import { firebaseConfig } from '../config/firebaseConfig';
import { useRoute } from '@react-navigation/native';

initializeApp(firebaseConfig);
const db = getFirestore();

export default function PharmacyDetail() {
  const route = useRoute();
  const { pharmacyId } = route.params;
  const [pharmacy, setPharmacy] = useState(null);
  const [medicines, setMedicines] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => { loadDetail(); }, [pharmacyId]);

  const loadDetail = async () => {
    setLoading(true);
    try {
      const pDoc = await getDoc(doc(db, 'pharmacies', pharmacyId));
      if (pDoc.exists()) setPharmacy({ id: pDoc.id, ...pDoc.data() });

      const pricesColl = collection(db, 'pharmacies', pharmacyId, 'prices');
      const q = query(pricesColl, orderBy('updatedAt', 'desc'));
      const snap = await getDocs(q);
      const meds = [];
      for (const d of snap.docs) {
        const data = d.data();
        let med = { id: data.medicineId, price: data.price };
        try {
          const mDoc = await getDoc(doc(db, 'medicines', data.medicineId));
          if (mDoc.exists()) med = { ...med, ...(mDoc.data()) };
        } catch (e) {}
        meds.push(med);
      }
      setMedicines(meds);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <ActivityIndicator />;
  if (!pharmacy) return <Text>Pharmacie introuvable</Text>;

  return (
    <View style={{ flex: 1, padding: 12 }}>
      <Text style={{ fontSize: 20, fontWeight: '700' }}>{pharmacy.name}</Text>
      <Text>{pharmacy.address} — {pharmacy.city}</Text>
      <TouchableOpacity onPress={() => Linking.openURL(`tel:${pharmacy.phone}`)}><Text>Appeler</Text></TouchableOpacity>

      <Text style={{ marginTop: 12, fontWeight: '700' }}>Médicaments & Prix</Text>
      <FlatList data={medicines} keyExtractor={i => i.id} renderItem={({ item }) => (
        <View style={{ paddingVertical: 8, borderBottomWidth: 1, borderColor: '#eee' }}>
          <Text style={{ fontWeight: '600' }}>{item.name} {item.genericName ? `(${item.genericName})` : ''}</Text>
          <Text>Dosage: {item.commonDosages ? item.commonDosages[0] : '-'}</Text>
          <Text>Prix: {item.price ? `${item.price} XOF` : 'N/A'}</Text>
        </View>
      )} />
    </View>
  );
}
