import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, TextInput, TouchableOpacity, ActivityIndicator, SafeAreaView } from 'react-native';
import { initializeApp } from 'firebase/app';
import { getFirestore, collection, query, where, getDocs, orderBy, limit } from 'firebase/firestore';
import { firebaseConfig } from '../config/firebaseConfig';

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

export default function PharmacyList({ navigation }) {
  const [city, setCity] = useState('Abidjan');
  const [search, setSearch] = useState('');
  const [pharmacies, setPharmacies] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => { fetchPharmacies(); }, [city]);

  const fetchPharmacies = async () => {
    setLoading(true);
    try {
      const coll = collection(db, 'pharmacies');
      const q = query(coll, where('city', '==', city), orderBy('name'), limit(50));
      const snap = await getDocs(q);
      const items = [];
      snap.forEach(doc => items.push({ id: doc.id, ...doc.data() }));
      setPharmacies(items);
    } catch (e) {
      console.error(e);
      setPharmacies([]);
    } finally {
      setLoading(false);
    }
  };

  const renderItem = ({ item }) => (
    <View style={{ padding: 12, borderBottomWidth: 1, borderColor: '#eee' }}>
      <Text style={{ fontWeight: '700' }}>{item.name}</Text>
      <Text>{item.address} — {item.phone}</Text>
      <View style={{ flexDirection: 'row', marginTop: 8 }}>
        <TouchableOpacity onPress={() => navigation.navigate('Detail', { pharmacyId: item.id })} style={{ marginRight: 12 }}>
          <Text style={{ color: '#007bff' }}>Voir détails</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('Map', { coords: item.coords })}>
          <Text style={{ color: '#007bff' }}>Voir sur la carte</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={{ flex: 1, padding: 12 }}>
      <Text style={{ fontSize: 20, fontWeight: '700', marginBottom: 8 }}>Pharmacies CI</Text>
      <TextInput placeholder="Ville (ex: Abidjan)" value={city} onChangeText={setCity} style={{ borderWidth:1, borderColor:'#ddd', borderRadius:8, padding:8, marginBottom:8 }} />
      <TextInput placeholder="Rechercher un médicament ou pharmacie" value={search} onChangeText={setSearch} style={{ borderWidth:1, borderColor:'#ddd', borderRadius:8, padding:8, marginBottom:8 }} />
      <TouchableOpacity onPress={fetchPharmacies} style={{ backgroundColor:'#1e90ff', padding:10, borderRadius:8, alignItems:'center', marginBottom:8 }}>
        <Text style={{ color:'white', fontWeight:'700' }}>Rechercher</Text>
      </TouchableOpacity>

      {loading ? <ActivityIndicator /> : (
        <FlatList data={pharmacies.filter(p => {
          if (!search) return true;
          const s = search.toLowerCase();
          return (p.name || '').toLowerCase().includes(s) || (p.address || '').toLowerCase().includes(s);
        })} keyExtractor={i => i.id} renderItem={renderItem} />
      )}
      <TouchableOpacity onPress={() => navigation.navigate('Garde')} style={{ marginTop: 12 }}>
        <Text style={{ color:'#1e90ff' }}>Voir pharmacies de garde</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}
