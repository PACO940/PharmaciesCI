import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import PharmacyList from './screens/PharmacyList';
import PharmacyDetail from './screens/PharmacyDetail';
import GardeScreen from './screens/GardeScreen';
import MapScreen from './screens/MapScreen';
import { LogBox } from 'react-native';
LogBox.ignoreAllLogs(true);

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="List">
        <Stack.Screen name="List" component={PharmacyList} options={{ title: 'Pharmacies CI' }} />
        <Stack.Screen name="Detail" component={PharmacyDetail} options={{ title: 'Détail pharmacie' }} />
        <Stack.Screen name="Garde" component={GardeScreen} options={{ title: 'Pharmacies de garde' }} />
        <Stack.Screen name="Map" component={MapScreen} options={{ title: 'Carte' }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
