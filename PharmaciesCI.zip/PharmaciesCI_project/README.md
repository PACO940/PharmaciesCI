PharmaciesCI - Starter Project
==============================
Contenu:
- App.js (Expo) + screens: PharmacyList, PharmacyDetail, GardeScreen, MapScreen
- config/firebaseConfig.js (place your Firebase config)
- data/*.csv : sample CSVs to import
- admin/: scaffold for admin web panel
- utils/haversine.js : distance utility

Instructions:
1) Installer Expo (https://docs.expo.dev/)
2) Copier le dossier sur votre machine ou exécuter 'npm install' puis 'expo start' dans le dossier principal
3) Remplacez config/firebaseConfig.js par votre configuration Firebase et activez Firestore
4) Importez les CSVs dans Firestore via console ou via Cloud Function d'import (non fournie)
5) Pour l'admin, cd admin && npm install && npm start (scaffold)

Règles Firestore conseillées (minimal, ajuster en production):
service cloud.firestore {
  match /databases/{database}/documents {
    match /pharmacies/{pharmacyId} {
      allow read: if true;
      allow write: if request.auth != null && request.auth.token.admin == true;
    }
    match /gardeSchedules/{g} {
      allow read: if true;
      allow write: if request.auth != null && request.auth.token.admin == true;
    }
    match /medicines/{m} {
      allow read: if true;
      allow write: if request.auth != null && request.auth.token.admin == true;
    }
  }
}
