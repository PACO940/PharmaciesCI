Mini panneau Admin (scaffold)
- login (Firebase Auth)
- CRUD pharmacies
- CRUD medicines
- Gestion gardes (calendar view recommended with FullCalendar)
Files:
- src/index.js (React app entry)
- src/firebase.js (config)
- src/App.js (router & pages)
This is a scaffold; implement UI using Material-UI or Chakra if desired.
